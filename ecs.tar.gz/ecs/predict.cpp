#include "predict.h"
#include "lib/lib_io.h"
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <algorithm>
#include <iomanip>
#include <math.h>
#include <random>
#include <map>
#include <string.h>
#include <iostream>
#include <vector>
#include <string>
#include <iterator>
#include <set>
#include <list>
#include <stack>
#include <stdio.h>
#include <time.h>
#include <sstream>

using namespace std;

int fcpu[15] = {1,1,1,2,2,2,4,4,4 ,8,8 ,8 ,16,16,16};
int fmem[15] = {1,2,4,2,4,8,4,8,16,8,16,32,16,32,64};
class machine{
public:
    int cpu;
    int mem;
    map<int,int> fdict;
    machine(int cpu,int mem){
        this->cpu = cpu;
        this->mem = mem;
    }

    void update_machine(int findex){
        this->cpu = this->cpu - fcpu[findex];
        this->mem = this->mem - fmem[findex];
        if(fdict.find(findex)!=fdict.end()){
            this->fdict[findex] += 1;
        } else{
            this->fdict[findex] = 1;
        }
    }
};

class machineGroup{
public:
    vector<machine> machinelist;

    void add_machine(machine new_machine){
        this->machinelist.push_back(new_machine);
    }
    void change_machine(int index,int findex){
        this->machinelist[index].update_machine(findex);
    }
};
int allot(int CPU,int MEM,vector<int> flist,vector<int> numlist,int dim){
    machineGroup machines = machineGroup();
    int numindex = -1;
    for(auto index : flist){
        cout << "index"<<index<<endl;
        numindex+=1;
        for(int number =0;number <numlist[numindex];number++){
            int machineIndex = -1;
            cout<<"machineslist.size():"<<machines.machinelist.size()<<endl;
            for(int i=0 ;i <machines.machinelist.size();i++){
                cout <<machines.machinelist[i].cpu<<" "<<machines.machinelist[i].mem<<endl;
                cout << fcpu[index]<<" "<<fmem[index]<<endl;
                if(machines.machinelist[i].cpu>fcpu[index] and machines.machinelist[i].mem>fmem[index]) {
                    machineIndex = i;
                    break;
                }
            }
            if(machineIndex!=-1){
                machines.change_machine(machineIndex,index);
            }else {
                machine new_machine = machine(CPU,MEM);
                machines.add_machine(new_machine);
                machines.change_machine(machines.machinelist.size()-1,index);
            }
        }
    }
    for(auto elem:machines.machinelist){
        cout << elem.cpu<<endl;
    }
    cout <<"machines 里面的fdict就是每个机器对应的时间 end"<<endl;
    return 0;
}

// int main(){
//     vector<int> flist;
//     flist.push_back(4);
//     flist.push_back(9);
//     flist.push_back(14);
//     vector<int> numlist;
//     numlist.push_back(3);
//     numlist.push_back(2);
//     numlist.push_back(1);
//     allot(56,128,flist,numlist,0);
//     return 0;
// }



//ÄãÒªÍê³ÉµÄ¹¦ÄÜ×ÜÈë¿Ú
// input traindata      outputfilename
void predict_server(char * info[MAX_INFO_NUM], char * data[MAX_DATA_NUM], int data_num, char * filename)
{
	// ÐèÒªÊä³öµÄÄÚÈÝ
	char * result_file = (char *)"17\n\n0 8 0 20";
    istringstream iss(info[0]), iss1(info[2]);
    int num_cpu, num_mem, count_flavor;
    iss >> num_cpu;
    iss >> num_mem;
    iss1 >> count_flavor;
    vector<int> flavor_list;
    for (int i = 3; i < 3 + count_flavor; ++i)
    {
        istringstream is(info[i]);
        string s_type;
        is >> s_type;
        int type = atoi(s_type.substr(6, s_type.size()).c_str());
        cout << type << endl;
        flavor_list.push_back(type);
    }

    istringstream is_t1(info[6+count_flavor]), is_t2(info[7+count_flavor]), is_type(info[4+count_flavor]);
    string s_type;
    is_type >> s_type;
    if (!strcmp(s_type.c_str() ,"CPU")) cout << 1 << endl;
    tm t1,t2;
    is_t1 >> get_time(&t1, "%Y-%m-%d %H:%M:%S");
    is_t2 >> get_time(&t2, "%Y-%m-%d %H:%M:%S");
    int delta_day = (mktime(&t2)-mktime(&t1))/ 86400;
    cout << delta_day << endl;

	// Ö±½Óµ÷ÓÃÊä³öÎÄ¼þµÄ·½·¨Êä³öµ½Ö¸¶¨ÎÄ¼þÖÐ(psÇë×¢Òâ¸ñÊ½µÄÕýÈ·ÐÔ£¬Èç¹ûÓÐ½â£¬µÚÒ»ÐÐÖ»ÓÐÒ»¸öÊý¾Ý£»µÚ¶þÐÐÎª¿Õ£»µÚÈýÐÐ¿ªÊ¼²ÅÊÇ¾ßÌåµÄÊý¾Ý£¬Êý¾ÝÖ®¼äÓÃÒ»¸ö¿Õ¸ñ·Ö¸ô¿ª)
	write_result(result_file, filename);
}